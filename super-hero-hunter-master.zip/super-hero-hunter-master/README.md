# Super-Hero-Hunter
An ultra-simple `HTML` + `CSS` + `JavaScript` Super-Hero-Hunter

### Interface
I tried to simplify the UI as much as possible so there is one input-box and two button/control for the superhero hunter : **Home**
**Search Input-box** **Favourites**

When "Home" Button is pressed/clicked it sends to Home Page .
When "Favourites" button is pressed/clicked it sends to Favourites Page and display the item which is marked as favourites.


### Website link:- https://rahulkumarnathu.github.io/super-hero-hunter/
